Page({
    
    initialData: {
      text: "This is page data."
    },
    onLoad: function(options) {
    },
    onReady: function() {
    },
    onShow: function() {
    },
    onHide: function() {
    },
    onUnload: function() {
    },
    onPageScroll: function() {
    },
    onResize: function() {
    },
    // Event handler.
    onMyFunc: function() {
      return "Respond data nèe";
    },
    onMyFunc2: function() {
      return "Respond data 2 nèeeeeeee"
    },
  });